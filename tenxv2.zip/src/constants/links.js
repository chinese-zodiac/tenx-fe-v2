export const LINK_TELEGRAM = 'https://t.me/CZodiacofficial';
export const LINK_DISCORD = 'https://discord.gg/wy3SX4Zq3Y';
export const LINK_TWITTER = 'https://x.com/zodiacs_c';

export const LINK_CZCASH = 'https://www.cz.cash';
export const LINK_BSCSCAN = 'https://bscscan.com';
export const LINK_GECKOTERMINAL = 'https://www.geckoterminal.com/';

export const LINK_TERMS_OF_USE =
  'https://docs.czodiac.com/czodiac-litepaper/terms-of-use';

export const LINK_PRIVACY_POLICY =
  'https://docs.czodiac.com/czodiac-litepaper/privacy-policy';
