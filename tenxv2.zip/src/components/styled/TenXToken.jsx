import { Box, Checkbox, IconButton, Stack, Typography, useTheme } from '@mui/material';
import { LINK_BSCSCAN, LINK_GECKOTERMINAL } from '../../constants/links';
import ButtonPrimary from './ButtonPrimary';
import ButtonImageLink from './ButtonImageLink';
import { czCashBuyLink } from '../../utils/czcashLink';
import { useAccount } from 'wagmi';
import ReactGA from 'react-ga4';
import dayjs from 'dayjs';
import { useEffect, useState } from 'react';
import { readContract } from '@wagmi/core';
import TenXTokenV2Abi from '../../abi/TenXTokenV2.json';
import SettingsIcon from '@mui/icons-material/Settings';
import { styled } from '@mui/system';
const StarCheckbox = styled(Checkbox)(({ theme }) => ({
  color: '#e16b31',
  '&:checked': {
    color: '#e16b31',
  },
  '& .MuiSvgIcon-root': {
    fontSize: 32, // Adjust the size of the star icon
  },
}));

// Star icon component
const StarIcon = (props) => (
  <svg
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    {...props}
  >
    <path
      d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"
      fill="currentColor"
    />
  </svg>
);
const BlueIconButton = styled(IconButton)(({ theme }) => ({
  color: '#1976d2', // Blue color
  '&:hover': {
    color: '#1565c0', // Darker blue color on hover
  },
}));
export default function TenXToken({
  tokenAddress,
  czusdPair,
  taxReceiver,
  czusdGrant,
  buyTax,
  buyBurn,
  sellTax,
  sellBurn,
  name,
  symbol,
  tokenLogoCID,
  launchTimestamp,
  descriptionMarkdownCID,
  tokenIndex
}) {
  const { address, isConnecting, isDisconnected } = useAccount();
  const [content, setContent] = useState('Loading...');
  const [holdings, setHoldings] = useState('Loading...');
  const [checked, setChecked] = useState(false);

  const handleChange = (event) => {
    setChecked(event.target.checked);
  };
  const theme = useTheme();

  useEffect(() => {
    const fetchFileContent = async (ipfsLink) => {
      try {
        const response = await fetch(ipfsLink);
        const text = await response.text(); // Convert the response to text
        const lines = text.split('\n').slice(0, 3).join('\n');
        setContent(lines); // Update state with the fetched content
      } catch (error) {
        console.error('Error fetching file from IPFS:', error);
        setContent('No data found'); // Update state with error message
      }
    };

    fetchFileContent(descriptionMarkdownCID); // Call the async function
  }, [descriptionMarkdownCID]);

  useEffect(() => {
    const getHoldings = async () => {
      try {
        const result = await readContract({
          address: tokenAddress,
          abi: TenXTokenV2Abi,
          functionName: 'balanceOf',
          args: [address]
        });
        setHoldings(result.toString());
      } catch (error) {
        console.error('Error fetching Holdings:', error);
        setContent('No data found');
      }
    };

    getHoldings(); // Call the async function
  }, [tokenAddress, address]);


  const getAge = (birthDate) => {

    const now = dayjs();
    const days = now.diff(birthDate, 'days');
    const hours = now.diff(birthDate, 'hours') % 24;
    const minutes = now.diff(birthDate, 'minutes') % 60;
    // console.log({ birthDate, today: dayjs().$d, diff: `${days} days, ${hours} hours, and ${minutes} minutes` })
    return `${days} days, ${hours} hours, and ${minutes} minutes`;
  };
  return (
    <Box
      sx={{
        padding: '0.5em',
        display: 'inline-block',
        fontSize: '0.89em',
        position: 'relative',
        borderRadius: '1.5em',
        border:
          !!address && taxReceiver == address ? 'solid 3px #ef915b' : 'none',
      }}
    >
      <Box
        sx={{
          position: 'absolute',
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
          backgroundColor: '#080830',
          opacity: '0.25',
          borderRadius: '1.5em',
          zIndex: -1,
        }}
      />
      <StarCheckbox
        icon={<StarIcon />}
        checkedIcon={<StarIcon />}
        checked={checked}
        onChange={handleChange}
      />
      <Box
        as="img"
        src={tokenLogoCID}
        sx={{
          width: '5em',
          heigh: '5em',
          margin: 0,
          marginLeft: '0.5em',
          padding: 0,
          backgroundColor: 'white',
          border: 'solid 0.15em white',
          borderRadius: '5em',
          '&:hover': {
            border: 'solid 0.15em grey',
            backgroundColor: 'grey',
          },
        }}
      />
      <Box
        direction="row"
        spacing={1}
        sx={{
          display: 'inline-block',
          width: '15em',
          textAlign: 'left',
          paddingLeft: '0.5em',
        }}
      >
        <Typography
          sx={{ lineHeight: '1.81em', fontSize: '2em' }}
        >{`${name?.substr(0, 8)} (${symbol?.substr(0, 4)})`}</Typography>
        <Box
          as="a"
          target="_blank"
          href={`${LINK_BSCSCAN}/token/${tokenAddress}`}
          sx={{
            margin: 0,
            padding: 0,
          }}
        >
          <Box
            as="img"
            src="./images/icons/bscscan.svg"
            sx={{
              width: '2em',
              heigh: '2em',
              margin: 0,
              marginLeft: '0.5em',
              padding: 0,
              backgroundColor: 'white',
              border: 'solid 0.15em white',
              borderRadius: '2em',
              '&:hover': {
                border: 'solid 0.15em grey',
                backgroundColor: 'grey',
              },
            }}
          />
        </Box>
        <Box
          as="a"
          target="_blank"
          href={`${LINK_GECKOTERMINAL}/bsc/pools/${czusdPair}`}
          sx={{
            margin: 0,
            padding: 0,
            height: '1.2em',
            width: '1.2em',
          }}
        >
          <Box
            as="img"
            src="./images/icons/chart.svg"
            sx={{
              width: '2em',
              heigh: '2em',
              margin: 0,
              padding: 0,
              backgroundColor: 'white',
              border: 'solid 0.15em white',
              borderRadius: '2em',
              marginLeft: '1em',
              '&:hover': {
                border: 'solid 0.15em grey',
                backgroundColor: 'grey',
              },
            }}
          />
        </Box>
      </Box>
      <BlueIconButton
      component="a" 
      href={'#'}
      target="_blank" 
      rel="noopener noreferrer" 
    >
      <SettingsIcon />
    </BlueIconButton>
      <Typography>
        Buy Fee/Burn: {(buyTax / 100).toFixed(2)}% /{' '}
        {(buyBurn / 100).toFixed(2)}
        %<br />
        Sell Fee/Burn: {(sellTax / 100).toFixed(2)}% /{' '}
        {(sellBurn / 100).toFixed(2)}%
        <br />
        Launch time:{new Date(launchTimestamp).toString()}
        <br />
        Age: {getAge(launchTimestamp)}
        <br />
        Your holdings: {holdings}
        <br />
        Description: {content}
      </Typography>
      <ButtonPrimary
        as="a"
        target="_blank"
        href={czCashBuyLink('BNB', tokenAddress)}
        sx={{
          width: '100%',
          marginTop: '0em',
          fontSize: '1.5em',
          padding: 0,
          position: 'relative',
          fontWeight: 'bold',
          textTransform: 'none',
          color: '#e16b31',
          borderRadius: '1.5em',
          border: 'solid 2px #e16b31',
          backgroundColor: '#f3f3f3',
          display: 'block',
          marginLeft: 'auto',
          marginRight: 'auto',
          textDecoration: 'none',
          '&:hover': {
            backgroundColor: '#080830',
          },
        }}
      >
        BUY {symbol?.substr(0, 7)}
      </ButtonPrimary>
      <ButtonPrimary
        as="a"
        target="_self"
        href={`/product/${tokenIndex}`}
        sx={{
          width: '100%',
          marginTop: '0em',
          fontSize: '1.5em',
          padding: 0,
          position: 'relative',
          fontWeight: 'bold',
          textTransform: 'none',
          color: '#e16b31',
          borderRadius: '1.5em',
          border: 'solid 2px #e16b31',
          backgroundColor: '#f3f3f3',
          display: 'block',
          marginLeft: 'auto',
          marginRight: 'auto',
          textDecoration: 'none',
          '&:hover': {
            backgroundColor: '#080830',
          },
        }}
      >
        Learn More
      </ButtonPrimary>
    </Box>
  );
}
